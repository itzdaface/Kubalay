# TikTok LIVE Streaming Overlay

Animated 9:16 overlay for TikTok LIVE Studio with real-time event integration.
Supports follows, gifts, subscriptions, shares, raids, likes, members, and moderators.

---

## Files

```
tiktok-overlay/
├── public/
│   └── overlay.html        ← The overlay (host this on GitHub Pages / Vercel)
├── server/
│   └── relay.js            ← Node.js relay server (Option B only)
├── package.json
├── vercel.json
├── .env.example
└── README.md
```

---

## Step 1 — Host the overlay

Push this repo to GitHub, then enable GitHub Pages on the `public/` folder.
Your overlay URL will be:
```
https://YOUR-USERNAME.github.io/YOUR-REPO/overlay.html
```

Or deploy to Vercel:
```bash
npx vercel --prod
```

---

## Option A — TikFinity (easiest, no server needed)

TikFinity is a free tool that bridges TikTok LIVE events into your overlay.

### Setup

1. Create a free account at https://tikfinity.zerody.one
2. Go to **Gallery of Overlays → Alert Source**
3. Copy your personal overlay WebSocket token URL — it looks like:
   `wss://tikfinity.zerody.one/ws/overlay?token=abc123...`
4. Open `public/overlay.html` in a text editor
5. Find the CONFIG block near the bottom and set:
   ```js
   INTEGRATION: 'tikfinity',
   TIKFINITY_WS_URL: 'wss://tikfinity.zerody.one/ws/overlay?token=YOUR_TOKEN_HERE',
   ```
6. Re-upload/redeploy the file

### Add to TikTok LIVE Studio

1. Open TikTok LIVE Studio
2. In your scene, click **+ Add Source → Link**
3. Paste your hosted overlay URL:
   `https://your-github-pages-url/overlay.html`
4. Set size to **1080 × 1920** (full 9:16)
5. Position it over your scene
6. In TikFinity, click **Connect** and start your stream
7. TikFinity detects your live and starts sending events → overlay reacts

---

## Option B — tiktok-live-api Relay Server (full control, no third-party)

Uses the unofficial tik.tools managed WebSocket API.
You run a small Node.js server that connects to your TikTok LIVE and
relays every event directly to the overlay.

### Get a free API key

Sign up at https://tik.tools — free sandbox tier, no credit card.

### Run locally

```bash
# Install dependencies
npm install

# Copy and fill in your env vars
cp .env.example .env
# Edit .env: set TIKTOK_USERNAME and TIKTOOL_API_KEY

# Start the relay
npm start
```

The relay will be running at `ws://localhost:3001`.

### Configure the overlay

Open `public/overlay.html`, find the CONFIG block, and set:
```js
INTEGRATION: 'relay',
RELAY_WS_URL: 'ws://localhost:3001',   // local
// or for hosted:
// RELAY_WS_URL: 'wss://your-relay.vercel.app',
```

### Deploy the relay to Vercel (so overlay can reach it from LIVE Studio)

Because TikTok LIVE Studio loads your overlay as a browser page, it can't
reach `localhost`. Deploy the relay to Vercel so the overlay can connect
from anywhere:

```bash
# Install Vercel CLI
npm i -g vercel

# Set secrets
vercel env add TIKTOK_USERNAME
vercel env add TIKTOOL_API_KEY

# Deploy
vercel --prod
```

Your relay WebSocket URL will be:
```
wss://your-project.vercel.app
```

Update `RELAY_WS_URL` in overlay.html to this URL, then redeploy overlay.

### Add to TikTok LIVE Studio

Same as Option A — add a **Link Source** with your overlay URL at 1080×1920.

---

## Add cameras in TikTok LIVE Studio

The overlay has 3 transparent zones:
- **Top 360px** — Cam 1 area (face cam)
- **Middle 1200px** — Game/main feed area
- **Bottom 360px** — Cam 2 area (reaction cam)

In LIVE Studio:
1. Add your **webcam** as a Video Capture source → position it in the top zone
2. Add your **game/gameplay** as a Game Capture or Screen Capture → middle zone
3. Add a second cam (or leave cam 2 as a placeholder) → bottom zone
4. Add the **overlay HTML** as a Link Source on top of everything (highest layer)

---

## Testing events

You can test any event without going live by adding URL params:

```
overlay.html?test=follow&user=TestUser
overlay.html?test=gift&user=TestUser
overlay.html?test=raid&user=TestUser
```

Or open the browser console on the overlay page and run:
```js
testEvent({ event: 'follow', username: 'TestUser' })
testEvent({ event: 'gift',   username: 'TestUser', giftName: 'Rose', amount: 10 })
testEvent({ event: 'sub',    username: 'TestUser' })
testEvent({ event: 'raid',   username: 'TestUser', amount: 150 })
```

---

## Customisation

All tunable values are in the `CONFIG` block at the bottom of `overlay.html`:

| Key              | Default | Description                          |
|------------------|---------|--------------------------------------|
| `INTEGRATION`    | `relay` | `'tikfinity'` or `'relay'`           |
| `GOAL_TARGET`    | `100`   | Total interactions for daily goal    |
| `BOSS_MAX_HP`    | `10000` | Boss health pool                     |
| `NOTIF_DURATION` | `4000`  | How long popups stay on screen (ms)  |

---

## Combo escalation

| Combo level | Effect               |
|-------------|----------------------|
| x5          | 🔥 Fire effects      |
| x10         | ⚡ Lightning storm   |
| x25         | ☄️ Meteor shower    |
| x50+        | 💥 Boss defeated     |

---

## Event → effect map

| Event        | Notification               | FX                              |
|--------------|----------------------------|---------------------------------|
| Follow       | NEW ADVENTURER JOINED!     | Burst + coins + float text      |
| Subscribe    | HERO STATUS ACHIEVED!      | Lightning + shake + burst       |
| Gift         | MAGICAL ARTIFACT!          | Coins + burst (escalates)       |
| Share        | THE REALM GROWS!           | Burst + shake                   |
| Like         | (feed only)                | Burst                           |
| Member join  | NEW MEMBER JOINED!         | Burst + float text              |
| Moderator    | NEW MODERATOR!             | Double lightning + burst        |
| Raid         | RAID INCOMING!!!           | Full screen — lightning + shake + fireworks + meteors |
| Goal/Boss    | GOAL COMPLETE!!!           | Everything                      |
