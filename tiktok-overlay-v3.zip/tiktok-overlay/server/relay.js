/**
 * TikTok LIVE → Overlay Relay Server
 * ------------------------------------
 * Connects to tiktok-live-api (tik.tools) via their WebSocket,
 * then re-broadcasts every event to your overlay HTML page.
 *
 * Works locally or deployed to Vercel / Railway / Render.
 *
 * SETUP:
 *   npm install
 *   TIKTOK_USERNAME=your_tiktok_username TIKTOOL_API_KEY=your_key node server/relay.js
 *
 * Get a free API key at: https://tik.tools
 */

const WebSocket  = require('ws');
const http       = require('http');

// ── Config ──────────────────────────────────────────
const PORT            = process.env.PORT            || 3001;
const TIKTOK_USERNAME = process.env.TIKTOK_USERNAME || 'YOUR_TIKTOK_USERNAME';
const TIKTOOL_API_KEY = process.env.TIKTOOL_API_KEY || 'YOUR_API_KEY';
const TIKTOOL_WS_URL  = `wss://ws.tik.tools/v2/chat/ws?apiKey=${TIKTOOL_API_KEY}&username=${TIKTOK_USERNAME}`;

// ── HTTP server (needed for Vercel / health checks) ─
const httpServer = http.createServer((req, res) => {
  res.writeHead(200, { 'Content-Type': 'text/plain' });
  res.end('TikTok LIVE Relay — OK');
});

// ── WebSocket server (overlay connects here) ────────
const wss = new WebSocket.Server({ server: httpServer });

const overlayClients = new Set();

wss.on('connection', (ws, req) => {
  console.log('[Overlay] Client connected from', req.socket.remoteAddress);
  overlayClients.add(ws);

  ws.on('close', () => {
    overlayClients.delete(ws);
    console.log('[Overlay] Client disconnected');
  });
});

function broadcastToOverlay(event) {
  const msg = JSON.stringify(event);
  for (const client of overlayClients) {
    if (client.readyState === WebSocket.OPEN) {
      client.send(msg);
    }
  }
}

// ── TikTok LIVE connection ───────────────────────────
let tiktokWs     = null;
let reconnecting = false;

function connectTikTok() {
  if (reconnecting) return;
  console.log(`[TikTok] Connecting as @${TIKTOK_USERNAME}...`);

  tiktokWs = new WebSocket(TIKTOOL_WS_URL);

  tiktokWs.on('open', () => {
    console.log('[TikTok] Connected to tik.tools WebSocket');
    reconnecting = false;
  });

  tiktokWs.on('message', (raw) => {
    let msg;
    try { msg = JSON.parse(raw); } catch { return; }

    // tik.tools sends: { type, data: { ... } }
    const type = (msg.type || '').toLowerCase();
    const d    = msg.data || {};

    // Map tik.tools event types → relay format overlay understands
    let event = null;

    switch (type) {
      case 'webcastsocial':      // follow or share
        if (d.displayType === 'pm_mt_guidance_viewer') {
          event = { event: 'follow', username: d.user?.nickname || 'Someone' };
        } else if (d.displayType?.includes('share')) {
          event = { event: 'share', username: d.user?.nickname || 'Someone' };
        }
        break;

      case 'webcastgiftmessage': // gift
        event = {
          event: 'gift',
          username: d.user?.nickname || 'Someone',
          giftName: d.giftDetails?.giftName || d.giftName || 'Gift',
          amount: d.repeatCount || d.count || 1,
          giftId: d.giftId,
          repeatEnd: d.repeatEnd,
        };
        break;

      case 'webcastmembersmessage': // viewer joins
        event = { event: 'member', username: d.user?.nickname || 'Someone' };
        break;

      case 'webcastsubmessage':  // subscription
        event = { event: 'sub', username: d.user?.nickname || 'Someone' };
        break;

      case 'webcastlikedata':    // likes
        event = {
          event: 'like',
          username: d.user?.nickname || 'Someone',
          amount: d.likeCount || 1,
        };
        break;

      case 'webcastroomviewersmessage': // viewer count update
        event = { event: 'viewers', viewers: d.viewerCount || 0 };
        break;

      case 'webcastlinkmicroomresultmessage': // battle/raid result
        event = { event: 'raid', username: d.hostUser?.nickname || 'Someone', amount: 50 };
        break;

      case 'webcastcontrolmessage':
        // Stream ended
        if (d.action === 3) console.log('[TikTok] Stream ended');
        break;

      default:
        // Forward unknown events raw so overlay can handle future types
        event = { event: type, raw: d };
    }

    if (event) {
      console.log(`[Event] ${event.event} — ${event.username || ''}`);
      broadcastToOverlay(event);
    }
  });

  tiktokWs.on('close', (code, reason) => {
    console.log(`[TikTok] Disconnected (${code}). Reconnecting in 5s...`);
    reconnecting = true;
    setTimeout(() => {
      reconnecting = false;
      connectTikTok();
    }, 5000);
  });

  tiktokWs.on('error', (err) => {
    console.error('[TikTok] Error:', err.message);
  });
}

// ── Start ────────────────────────────────────────────
httpServer.listen(PORT, () => {
  console.log(`\n🎮 TikTok LIVE Relay running on port ${PORT}`);
  console.log(`   Overlay WebSocket: ws://localhost:${PORT}`);
  console.log(`   TikTok username:   @${TIKTOK_USERNAME}\n`);
  connectTikTok();
});

// Graceful shutdown
process.on('SIGINT', () => {
  console.log('\nShutting down...');
  if (tiktokWs) tiktokWs.close();
  wss.close();
  httpServer.close();
  process.exit(0);
});
